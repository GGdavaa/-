## What does this PR do?

<!-- Brief description of the change -->

## Type of change

- [ ] New cog (add ADR in `docs/adrs/`)
- [ ] Bug fix
- [ ] Feature / enhancement
- [ ] Refactor
- [ ] Docs / CI / infra

## Checklist

- [ ] `cargo check --all-targets` passes
- [ ] `cargo test --all-targets` passes
- [ ] `cargo fmt --all` applied
- [ ] `cargo clippy --all-targets -- -D warnings` clean
- [ ] `.env.example` updated if new env vars added
- [ ] ADR added for new cog (if applicable)
- [ ] Manifest `cog.toml` id matches directory name
- [ ] Binary name in `Cargo.toml` is `cog-<dir-name>`
