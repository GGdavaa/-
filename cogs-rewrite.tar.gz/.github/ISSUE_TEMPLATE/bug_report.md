---
name: Bug report
about: Something is broken
labels: bug
---

**Describe the bug**
<!-- Clear description -->

**To reproduce**
<!-- Steps to reproduce -->

**Expected behaviour**
<!-- What should happen -->

**Environment**
- OS:
- Rust version (`rustc --version`):
- Railway region (if deployment issue):
- Cog name (if cog-specific):

**Logs**
```
paste relevant logs here
```
