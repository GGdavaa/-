---
name: New cog proposal
about: Propose a new cog for the ecosystem
labels: new-cog
---

**Cog name (slug)**
<!-- e.g. `gesture-detect` -->

**Purpose**
<!-- One sentence: what does this cog do? -->

**Sensor inputs**
<!-- What data sources / signals does it consume? -->

**Outputs / actions**
<!-- What does it emit or control? -->

**RuView dependency**
- [ ] None
- [ ] Optional (degrades gracefully without WiFi-CSI)
- [ ] Required

**Relevant ADR**
<!-- Link or draft the ADR here before implementation begins -->
